import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { CarouselModule } from 'ngx-owl-carousel-o';
// import { OwlOptions } from 'ngx-owl-carousel-o';
// import { BrowserModule } from '@angular/platform-browser';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations'; // ✅ Add this


@Component({
  selector: 'app-clients',
  imports: [CommonModule],
  templateUrl: './clients.component.html',
  styleUrl: './clients.component.css'
})
export class ClientsComponent {
  clientLogos: string[] = [
    '../assets/images/clients/sc.png',
    '../assets/images/clients/NSE_IT.png',
    '../assets/images/clients/yes_bank_logo.png',
  ];

  // customOptions: OwlOptions = {
  //   loop: true,
  //   margin: 10,
  //   nav: false,
  //   dots: true,
  //   autoplay: true,
  //   autoplayTimeout: 3000,
  //   responsive: {
  //     0: {
  //       items: 2
  //     },
  //     600: {
  //       items: 3
  //     },
  //     1000: {
  //       items: 5
  //     }
  //   }
  // };
}
