import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-solutions',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './solutions.component.html',
  styleUrl: './solutions.component.css'
})
export class SolutionsComponent {
  
  cards = [
    {
      icon: 'fas fa-code',
      title: 'API Banking',
      subtitle: 'More Innovation and Revenue',
      description: 'Open Banking is a one solution to manage open banking services for financial institutions.',
      link: 'https://unacores.com/api-banking/'
    },
    {
      icon: 'fas fa-microchip',
      title: 'Neo Banking',
      subtitle: 'New age secure solutions',
      description: 'Cutting edge simple, secure, smart interfaces for the bank’s corporate customers',
      link: 'https://unacores.com/neo-banking/'
    },
    {
      icon: 'fas fa-cube',
      title: 'Our Services',
      subtitle: 'Customer Friendly our Services',
      description: 'All in one solution Banking for Customers',
      link: 'https://unacores.com/software-development/'
    },
    {
      icon: 'fas fa-code',
      title: 'API Banking',
      subtitle: 'More Innovation and Revenue',
      description: 'Open Banking is a one solution to manage open banking services for financial institutions.',
      link: 'https://unacores.com/api-banking/'
    },
    {
      icon: 'fas fa-microchip',
      title: 'Neo Banking',
      subtitle: 'New age secure solutions',
      description: 'Cutting edge simple, secure, smart interfaces for the bank’s corporate customers',
      link: 'https://unacores.com/neo-banking/'
    },
    {
      icon: 'fas fa-cube',
      title: 'Our Services',
      subtitle: 'Customer Friendly our Services',
      description: 'All in one solution Banking for Customers',
      link: 'https://unacores.com/software-development/'
    }
  ];
  faqs = [
    {
      question: 'How do I submit a ticket?',
      answer: 'Click the "Submit a Ticket" button in the top-right or in the support section.'
    },
    {
      question: 'Can I contact support via WhatsApp?',
      answer: 'Yes, click the floating WhatsApp icon to start a conversation directly.'
    },
    {
      question: 'How do I update my profile?',
      answer: 'Click your profile icon and select "My Profile" from the dropdown menu.'
    }
  ];

  activeIndex: number | null = null;

  toggleIcon(index: number) {
    this.activeIndex = this.activeIndex === index ? null : index;
  }
}
