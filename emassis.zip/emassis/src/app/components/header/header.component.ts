import { Component, ViewChild, ElementRef } from '@angular/core';
import { Modal } from 'bootstrap';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
  imports: [
  ],
})
export class HeaderComponent {
  @ViewChild('loginModal', { static: false }) loginModalRef!: ElementRef;
  loginModalInstance: any;

  openLoginModal() {
    const modalElement = this.loginModalRef.nativeElement;
    this.loginModalInstance = new Modal(modalElement);
    this.loginModalInstance.show();
  }
}
