import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-hero',
  imports: [CommonModule],
  templateUrl: './hero.component.html',
  styleUrl: './hero.component.css'
})
export class HeroComponent implements OnInit {
  banners = [
    { image: '../../../assets/images/banner-2.jpeg' },
    { image: '../../../assets/images/images.jpeg' },
    { image: '../../../assets/images/idaho239691_1920.jpg' }
  ];
  currentIndex = 0;

  ngOnInit(): void {
    setInterval(() => this.nextSlide(), 5000); // Auto slide every 5s
  }

  nextSlide() {
    this.currentIndex = (this.currentIndex + 1) % this.banners.length;
  }

  goToSlide(index: number) {
    this.currentIndex = index;
  }
}