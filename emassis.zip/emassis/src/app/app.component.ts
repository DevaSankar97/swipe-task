import { Component,OnInit } from '@angular/core';
// import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from './components/header/header.component';
import { HeroComponent } from './components/hero/hero.component';
import { SolutionsComponent } from './components/solutions/solutions.component';
import { FooterComponent } from './components/footer/footer.component';
import AOS from 'aos';
import 'aos/dist/aos.css';


@Component({
  selector: 'app-root',
  imports: [HeaderComponent,HeroComponent,SolutionsComponent,FooterComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'emassis';
  ngOnInit(): void {
    // if (window.innerWidth > 768) { // Only init AOS for desktop
      AOS.init({
        duration: 800,
        once: true,
        offset: 100
      });
    // }
  }
}
